const colors = {
  light: {
    text: "#f5f5f7",
    tint: "#a855f7",

    background: "#0a0a14",
    foreground: "#f5f5f7",

    card: "#14141f",
    cardForeground: "#f5f5f7",

    primary: "#a855f7",
    primaryForeground: "#ffffff",

    secondary: "#1f1f2e",
    secondaryForeground: "#f5f5f7",

    muted: "#1a1a26",
    mutedForeground: "#8a8a9a",

    accent: "#22d3ee",
    accentForeground: "#0a0a14",

    destructive: "#ef4444",
    destructiveForeground: "#ffffff",

    border: "#252535",
    input: "#1f1f2e",
  },

  dark: {
    text: "#f5f5f7",
    tint: "#a855f7",

    background: "#0a0a14",
    foreground: "#f5f5f7",

    card: "#14141f",
    cardForeground: "#f5f5f7",

    primary: "#a855f7",
    primaryForeground: "#ffffff",

    secondary: "#1f1f2e",
    secondaryForeground: "#f5f5f7",

    muted: "#1a1a26",
    mutedForeground: "#8a8a9a",

    accent: "#22d3ee",
    accentForeground: "#0a0a14",

    destructive: "#ef4444",
    destructiveForeground: "#ffffff",

    border: "#252535",
    input: "#1f1f2e",
  },

  radius: 16,
};

export default colors;
