export type AskResult =
  | { ok: true; answer: string }
  | { ok: false; error: string };

function joinUrl(base: string, path: string): string {
  const b = base.replace(/\/+$/, "");
  const p = path.replace(/^\/+/, "");
  return `${b}/${p}`;
}

export async function askAi(
  serverUrl: string,
  question: string,
  signal?: AbortSignal,
): Promise<AskResult> {
  const url = serverUrl?.trim();
  if (!url) {
    return {
      ok: false,
      error:
        "AI server not set. Open Voice → Settings and paste your AI server URL.",
    };
  }
  const q = question.trim();
  if (!q) return { ok: false, error: "Empty question." };

  try {
    const res = await fetch(joinUrl(url, "/api/ai/ask"), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ question: q }),
      signal,
    });
    const data = (await res.json().catch(() => null)) as
      | { ok?: boolean; answer?: string; error?: string }
      | null;
    if (!res.ok || !data || data.ok === false) {
      return {
        ok: false,
        error: data?.error || `AI request failed (HTTP ${res.status})`,
      };
    }
    if (typeof data.answer === "string" && data.answer.trim()) {
      return { ok: true, answer: data.answer.trim() };
    }
    return { ok: false, error: "Empty response from AI." };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return { ok: false, error: `AI request failed: ${msg}` };
  }
}
