export type RGB = { r: number; g: number; b: number };

export type Device = {
  id: string;
  name: string;
  color: RGB;
  brightness: number;
  isOn: boolean;
  lastSeen: number;
};

export type Group = {
  id: string;
  name: string;
  deviceIds: string[];
  color?: RGB;
};

export type CommandActionKind =
  | "on"
  | "off"
  | "color"
  | "brightness"
  | "scene"
  | "music";

export type Scene =
  | "rainbow"
  | "warm"
  | "cool"
  | "party"
  | "calm"
  | "fire"
  | "ocean";

export type CommandTarget =
  | { kind: "all" }
  | { kind: "device"; id: string }
  | { kind: "group"; id: string };

export type VoiceCommand = {
  id: string;
  phrase: string;
  action: CommandActionKind;
  target: CommandTarget;
  color?: RGB;
  brightness?: number;
  scene?: Scene;
  enabled: boolean;
};
