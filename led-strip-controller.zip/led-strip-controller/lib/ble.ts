import { Platform } from "react-native";
import { BleManager, Device as BleDevice } from "react-native-ble-plx";
import { Buffer } from "buffer";
import type { RGB } from "./types";

// Common BLE service/characteristic UUIDs used by cheap LED strips
// (LotusLampX / ELK-BLEDOM / MELK / Triones / Happy Lighting variants).
const KNOWN_WRITE_TARGETS: { service: string; characteristic: string }[] = [
  { service: "0000ffd5-0000-1000-8000-00805f9b34fb", characteristic: "0000ffd9-0000-1000-8000-00805f9b34fb" },
  { service: "0000ffe5-0000-1000-8000-00805f9b34fb", characteristic: "0000ffe9-0000-1000-8000-00805f9b34fb" },
  { service: "0000fff0-0000-1000-8000-00805f9b34fb", characteristic: "0000fff3-0000-1000-8000-00805f9b34fb" },
  { service: "0000fff0-0000-1000-8000-00805f9b34fb", characteristic: "0000fff4-0000-1000-8000-00805f9b34fb" },
];

// Heuristic: cheap LED strips usually advertise with these prefixes
const NAME_PREFIXES = [
  "LEDBLE",
  "ELK-BLE",
  "MELK",
  "LEDnet",
  "BLEDOM",
  "Triones",
  "QHM",
  "LotusLamp",
  "Lotus",
  "LED",
  "iBT",
  "MohuanLED",
];

export function looksLikeLed(name: string | null | undefined): boolean {
  if (!name) return false;
  const upper = name.toUpperCase();
  return NAME_PREFIXES.some((p) => upper.includes(p.toUpperCase()));
}

let manager: BleManager | null = null;
export function getManager(): BleManager {
  if (!manager) manager = new BleManager();
  return manager;
}

const connectedCache = new Map<string, BleDevice>();
const writeTargetCache = new Map<string, { service: string; characteristic: string }>();

export type ScanResult = {
  id: string;
  name: string;
  rssi: number | null;
};

export async function scanForDevices(
  onFound: (d: ScanResult) => void,
  durationMs = 8000,
): Promise<void> {
  const m = getManager();
  const seen = new Set<string>();
  return new Promise((resolve, reject) => {
    m.startDeviceScan(null, { allowDuplicates: false }, (error, device) => {
      if (error) {
        m.stopDeviceScan();
        reject(error);
        return;
      }
      if (!device || !device.id) return;
      if (seen.has(device.id)) return;
      const name = device.name || device.localName || "";
      if (!name) return;
      seen.add(device.id);
      onFound({ id: device.id, name, rssi: device.rssi ?? null });
    });
    setTimeout(() => {
      m.stopDeviceScan();
      resolve();
    }, durationMs);
  });
}

export function stopScan(): void {
  getManager().stopDeviceScan();
}

async function discoverWriteTarget(
  device: BleDevice,
): Promise<{ service: string; characteristic: string } | null> {
  const cached = writeTargetCache.get(device.id);
  if (cached) return cached;

  // Try known targets first.
  const services = await device.services();
  const serviceIds = new Set(services.map((s) => s.uuid.toLowerCase()));

  for (const target of KNOWN_WRITE_TARGETS) {
    if (!serviceIds.has(target.service)) continue;
    try {
      const chars = await device.characteristicsForService(target.service);
      const found = chars.find(
        (c) => c.uuid.toLowerCase() === target.characteristic,
      );
      if (found && (found.isWritableWithResponse || found.isWritableWithoutResponse)) {
        writeTargetCache.set(device.id, target);
        return target;
      }
    } catch {
      /* continue */
    }
  }

  // Fallback: scan everything for first writable characteristic.
  for (const service of services) {
    try {
      const chars = await device.characteristicsForService(service.uuid);
      const writable = chars.find(
        (c) => c.isWritableWithResponse || c.isWritableWithoutResponse,
      );
      if (writable) {
        const target = { service: service.uuid, characteristic: writable.uuid };
        writeTargetCache.set(device.id, target);
        return target;
      }
    } catch {
      /* continue */
    }
  }
  return null;
}

export async function connect(deviceId: string): Promise<BleDevice> {
  const m = getManager();
  const cached = connectedCache.get(deviceId);
  if (cached) {
    try {
      const isConn = await cached.isConnected();
      if (isConn) return cached;
    } catch {
      /* fallthrough */
    }
  }
  const dev = await m.connectToDevice(deviceId, { timeout: 10000 });
  await dev.discoverAllServicesAndCharacteristics();
  connectedCache.set(deviceId, dev);
  return dev;
}

export async function disconnect(deviceId: string): Promise<void> {
  const m = getManager();
  try {
    await m.cancelDeviceConnection(deviceId);
  } catch {
    /* ignore */
  }
  connectedCache.delete(deviceId);
  writeTargetCache.delete(deviceId);
}

async function writeBytes(deviceId: string, bytes: number[]): Promise<void> {
  const dev = await connect(deviceId);
  const target = await discoverWriteTarget(dev);
  if (!target) {
    throw new Error("No writable characteristic found on this device");
  }
  const payload = Buffer.from(bytes).toString("base64");
  try {
    await dev.writeCharacteristicWithoutResponseForService(
      target.service,
      target.characteristic,
      payload,
    );
  } catch {
    await dev.writeCharacteristicWithResponseForService(
      target.service,
      target.characteristic,
      payload,
    );
  }
}

// LotusLampX / ELK-BLEDOM 9-byte protocol: 7E 00 [op] [data...] EF
// Documented across the cheap LED strip ecosystem.
const cmd = {
  on: () => [0x7e, 0x00, 0x04, 0xf0, 0x00, 0x01, 0xff, 0x00, 0xef],
  off: () => [0x7e, 0x00, 0x04, 0x00, 0x00, 0x00, 0xff, 0x00, 0xef],
  color: ({ r, g, b }: RGB) => [
    0x7e, 0x00, 0x05, 0x03, r & 0xff, g & 0xff, b & 0xff, 0x00, 0xef,
  ],
  brightness: (pct: number) => {
    const v = Math.max(0, Math.min(100, Math.round(pct)));
    return [0x7e, 0x00, 0x01, v, 0x00, 0x00, 0x00, 0x00, 0xef];
  },
  scene: (id: number) => [
    0x7e, 0x00, 0x03, id & 0xff, 0x03, 0x00, 0x00, 0x00, 0xef,
  ],
};

export const SCENE_IDS: Record<string, number> = {
  rainbow: 0x87,
  warm: 0x82,
  cool: 0x83,
  party: 0x88,
  calm: 0x84,
  fire: 0x86,
  ocean: 0x85,
};

export const led = {
  setOn: (id: string) => writeBytes(id, cmd.on()),
  setOff: (id: string) => writeBytes(id, cmd.off()),
  setColor: (id: string, c: RGB) => writeBytes(id, cmd.color(c)),
  setBrightness: (id: string, pct: number) => writeBytes(id, cmd.brightness(pct)),
  setScene: (id: string, name: keyof typeof SCENE_IDS) =>
    writeBytes(id, cmd.scene(SCENE_IDS[name] ?? SCENE_IDS["rainbow"]!)),
};

export const isBleSupported = Platform.OS === "android" || Platform.OS === "ios";
