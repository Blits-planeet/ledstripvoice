import {
  ExpoSpeechRecognitionModule,
  useSpeechRecognitionEvent,
} from "expo-speech-recognition";

export { ExpoSpeechRecognitionModule, useSpeechRecognitionEvent };

export type RecognizerOptions = {
  continuous?: boolean;
  interim?: boolean;
  lang?: string;
};

export function startListening(opts: RecognizerOptions = {}): void {
  ExpoSpeechRecognitionModule.start({
    lang: opts.lang ?? "en-US",
    interimResults: opts.interim ?? true,
    continuous: opts.continuous ?? false,
    requiresOnDeviceRecognition: false,
    addsPunctuation: false,
  });
}

export function stopListening(): void {
  try {
    ExpoSpeechRecognitionModule.stop();
  } catch {
    /* noop */
  }
}

export function abortListening(): void {
  try {
    ExpoSpeechRecognitionModule.abort();
  } catch {
    /* noop */
  }
}

// Match transcript against a phrase. Returns confidence 0..1.
export function matchPhrase(transcript: string, phrase: string): number {
  const t = transcript.toLowerCase().replace(/[^a-z0-9 ]/g, "").trim();
  const p = phrase.toLowerCase().replace(/[^a-z0-9 ]/g, "").trim();
  if (!t || !p) return 0;
  if (t === p) return 1;
  if (t.includes(p)) return 0.9;

  // Token overlap
  const tt = new Set(t.split(/\s+/));
  const pp = p.split(/\s+/);
  let hits = 0;
  for (const w of pp) if (tt.has(w)) hits++;
  return hits / pp.length;
}
