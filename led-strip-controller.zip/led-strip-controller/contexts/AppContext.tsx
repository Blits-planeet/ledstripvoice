import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  Device,
  Group,
  RGB,
  Scene,
  VoiceCommand,
  CommandActionKind,
  CommandTarget,
} from "@/lib/types";
import { storage, Settings, DEFAULT_SETTINGS } from "@/lib/storage";
import { led } from "@/lib/ble";
import { startMeter, stopMeter, subscribeLevel } from "@/lib/audio";

type Ctx = {
  ready: boolean;
  devices: Device[];
  groups: Group[];
  commands: VoiceCommand[];
  settings: Settings;
  busy: Record<string, boolean>;
  // device CRUD
  upsertDevice: (d: Device) => Promise<void>;
  removeDevice: (id: string) => Promise<void>;
  renameDevice: (id: string, name: string) => Promise<void>;
  // group CRUD
  createGroup: (name: string, deviceIds: string[]) => Promise<Group>;
  updateGroup: (g: Group) => Promise<void>;
  removeGroup: (id: string) => Promise<void>;
  // commands CRUD
  upsertCommand: (c: VoiceCommand) => Promise<void>;
  removeCommand: (id: string) => Promise<void>;
  // settings
  updateSettings: (patch: Partial<Settings>) => Promise<void>;
  // led control
  controlPower: (target: CommandTarget, on: boolean) => Promise<void>;
  controlColor: (target: CommandTarget, c: RGB) => Promise<void>;
  controlBrightness: (target: CommandTarget, pct: number) => Promise<void>;
  controlScene: (target: CommandTarget, scene: Scene) => Promise<void>;
  // music vibe
  musicMode: { active: boolean; target: CommandTarget | null };
  startMusicMode: (target: CommandTarget) => Promise<void>;
  stopMusicMode: () => Promise<void>;
  // execute
  executeCommand: (cmd: VoiceCommand) => Promise<string>;
  matchAndExecute: (transcript: string) => Promise<{
    cmd: VoiceCommand | null;
    confidence: number;
    message: string;
  }>;
};

const AppContext = createContext<Ctx | null>(null);

function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function targetDeviceIds(
  target: CommandTarget,
  devices: Device[],
  groups: Group[],
): string[] {
  if (target.kind === "all") return devices.map((d) => d.id);
  if (target.kind === "device") return [target.id];
  const g = groups.find((x) => x.id === target.id);
  return g ? g.deviceIds : [];
}

function targetLabel(
  target: CommandTarget,
  devices: Device[],
  groups: Group[],
): string {
  if (target.kind === "all") return "all lights";
  if (target.kind === "device") {
    const d = devices.find((x) => x.id === target.id);
    return d ? d.name : "unknown light";
  }
  const g = groups.find((x) => x.id === target.id);
  return g ? `group "${g.name}"` : "unknown group";
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [devices, setDevices] = useState<Device[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [commands, setCommands] = useState<VoiceCommand[]>([]);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [busy, setBusy] = useState<Record<string, boolean>>({});
  const [musicMode, setMusicMode] = useState<{
    active: boolean;
    target: CommandTarget | null;
  }>({ active: false, target: null });

  const devicesRef = useRef(devices);
  const groupsRef = useRef(groups);
  useEffect(() => {
    devicesRef.current = devices;
  }, [devices]);
  useEffect(() => {
    groupsRef.current = groups;
  }, [groups]);

  useEffect(() => {
    (async () => {
      const [d, g, c, s] = await Promise.all([
        storage.loadDevices(),
        storage.loadGroups(),
        storage.loadCommands(),
        storage.loadSettings(),
      ]);
      setDevices(d);
      setGroups(g);
      setCommands(c.length ? c : seedCommands());
      setSettings(s);
      setReady(true);
    })();
  }, []);

  const setBusyFor = useCallback((id: string, v: boolean) => {
    setBusy((prev) => ({ ...prev, [id]: v }));
  }, []);

  const upsertDevice = useCallback(async (d: Device) => {
    setDevices((prev) => {
      const exists = prev.some((x) => x.id === d.id);
      const next = exists ? prev.map((x) => (x.id === d.id ? d : x)) : [...prev, d];
      void storage.saveDevices(next);
      return next;
    });
  }, []);

  const removeDevice = useCallback(async (id: string) => {
    setDevices((prev) => {
      const next = prev.filter((d) => d.id !== id);
      void storage.saveDevices(next);
      return next;
    });
    setGroups((prev) => {
      const next = prev.map((g) => ({
        ...g,
        deviceIds: g.deviceIds.filter((x) => x !== id),
      }));
      void storage.saveGroups(next);
      return next;
    });
  }, []);

  const renameDevice = useCallback(async (id: string, name: string) => {
    setDevices((prev) => {
      const next = prev.map((d) => (d.id === id ? { ...d, name } : d));
      void storage.saveDevices(next);
      return next;
    });
  }, []);

  const createGroup = useCallback(
    async (name: string, deviceIds: string[]) => {
      const g: Group = { id: uid(), name, deviceIds };
      setGroups((prev) => {
        const next = [...prev, g];
        void storage.saveGroups(next);
        return next;
      });
      return g;
    },
    [],
  );

  const updateGroup = useCallback(async (g: Group) => {
    setGroups((prev) => {
      const next = prev.map((x) => (x.id === g.id ? g : x));
      void storage.saveGroups(next);
      return next;
    });
  }, []);

  const removeGroup = useCallback(async (id: string) => {
    setGroups((prev) => {
      const next = prev.filter((g) => g.id !== id);
      void storage.saveGroups(next);
      return next;
    });
  }, []);

  const upsertCommand = useCallback(async (c: VoiceCommand) => {
    setCommands((prev) => {
      const exists = prev.some((x) => x.id === c.id);
      const next = exists ? prev.map((x) => (x.id === c.id ? c : x)) : [...prev, c];
      void storage.saveCommands(next);
      return next;
    });
  }, []);

  const removeCommand = useCallback(async (id: string) => {
    setCommands((prev) => {
      const next = prev.filter((c) => c.id !== id);
      void storage.saveCommands(next);
      return next;
    });
  }, []);

  const updateSettings = useCallback(async (patch: Partial<Settings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      void storage.saveSettings(next);
      return next;
    });
  }, []);

  const runOnTargets = useCallback(
    async (
      target: CommandTarget,
      fn: (id: string) => Promise<void>,
      patch: (d: Device) => Partial<Device>,
    ) => {
      const ids = targetDeviceIds(target, devicesRef.current, groupsRef.current);
      await Promise.all(
        ids.map(async (id) => {
          setBusyFor(id, true);
          try {
            await fn(id);
            setDevices((prev) => {
              const next = prev.map((d) => (d.id === id ? { ...d, ...patch(d) } : d));
              void storage.saveDevices(next);
              return next;
            });
          } catch (err) {
            console.warn("BLE write failed", id, err);
          } finally {
            setBusyFor(id, false);
          }
        }),
      );
    },
    [setBusyFor],
  );

  const controlPower = useCallback(
    async (target: CommandTarget, on: boolean) => {
      await runOnTargets(
        target,
        (id) => (on ? led.setOn(id) : led.setOff(id)),
        () => ({ isOn: on }),
      );
    },
    [runOnTargets],
  );

  const controlColor = useCallback(
    async (target: CommandTarget, c: RGB) => {
      await runOnTargets(
        target,
        (id) => led.setColor(id, c),
        () => ({ color: c, isOn: true }),
      );
    },
    [runOnTargets],
  );

  const controlBrightness = useCallback(
    async (target: CommandTarget, pct: number) => {
      await runOnTargets(
        target,
        (id) => led.setBrightness(id, pct),
        () => ({ brightness: pct }),
      );
    },
    [runOnTargets],
  );

  const controlScene = useCallback(
    async (target: CommandTarget, scene: Scene) => {
      await runOnTargets(
        target,
        (id) => led.setScene(id, scene),
        () => ({ isOn: true }),
      );
    },
    [runOnTargets],
  );

  // Music vibe mode
  const lastSentRef = useRef(0);
  const startMusicMode = useCallback(
    async (target: CommandTarget) => {
      await startMeter();
      const unsub = subscribeLevel((level) => {
        const now = Date.now();
        if (now - lastSentRef.current < 180) return;
        lastSentRef.current = now;
        const sensitivity = settings.musicSensitivity || 0.5;
        const boosted = Math.min(1, level / Math.max(0.1, 1 - sensitivity));
        // Map level to a hue spinning around the wheel based on time, sat=1, val=level
        const hue = (now / 30) % 360;
        const c = hsvToRgb(hue, 1, boosted);
        void controlColor(target, c);
      });
      // store unsub on the state object
      setMusicMode({ active: true, target });
      stopMusicUnsub.current = unsub;
    },
    [controlColor, settings.musicSensitivity],
  );
  const stopMusicUnsub = useRef<(() => void) | null>(null);
  const stopMusicMode = useCallback(async () => {
    stopMusicUnsub.current?.();
    stopMusicUnsub.current = null;
    await stopMeter();
    setMusicMode({ active: false, target: null });
  }, []);

  const executeCommand = useCallback(
    async (cmd: VoiceCommand): Promise<string> => {
      const label = targetLabel(cmd.target, devicesRef.current, groupsRef.current);
      switch (cmd.action) {
        case "on":
          await controlPower(cmd.target, true);
          return `Turned ${label} on`;
        case "off":
          await controlPower(cmd.target, false);
          return `Turned ${label} off`;
        case "color":
          if (cmd.color) {
            await controlColor(cmd.target, cmd.color);
            return `Set color on ${label}`;
          }
          return "Command has no color";
        case "brightness":
          if (typeof cmd.brightness === "number") {
            await controlBrightness(cmd.target, cmd.brightness);
            return `Set brightness ${cmd.brightness}% on ${label}`;
          }
          return "Command has no brightness";
        case "scene":
          if (cmd.scene) {
            await controlScene(cmd.target, cmd.scene);
            return `Started ${cmd.scene} on ${label}`;
          }
          return "Command has no scene";
        case "music":
          await startMusicMode(cmd.target);
          return `Music vibe started on ${label}`;
      }
    },
    [controlBrightness, controlColor, controlPower, controlScene, startMusicMode],
  );

  const matchAndExecute = useCallback(
    async (transcript: string) => {
      const text = transcript.toLowerCase();
      let best: { cmd: VoiceCommand; score: number } | null = null;
      for (const c of commands) {
        if (!c.enabled) continue;
        const score = scorePhrase(text, c.phrase);
        if (score > 0.55 && (!best || score > best.score)) {
          best = { cmd: c, score };
        }
      }
      if (!best) {
        return {
          cmd: null,
          confidence: 0,
          message: `No matching command for "${transcript}"`,
        };
      }
      const message = await executeCommand(best.cmd);
      return { cmd: best.cmd, confidence: best.score, message };
    },
    [commands, executeCommand],
  );

  const value = useMemo<Ctx>(
    () => ({
      ready,
      devices,
      groups,
      commands,
      settings,
      busy,
      upsertDevice,
      removeDevice,
      renameDevice,
      createGroup,
      updateGroup,
      removeGroup,
      upsertCommand,
      removeCommand,
      updateSettings,
      controlPower,
      controlColor,
      controlBrightness,
      controlScene,
      musicMode,
      startMusicMode,
      stopMusicMode,
      executeCommand,
      matchAndExecute,
    }),
    [
      ready,
      devices,
      groups,
      commands,
      settings,
      busy,
      musicMode,
      upsertDevice,
      removeDevice,
      renameDevice,
      createGroup,
      updateGroup,
      removeGroup,
      upsertCommand,
      removeCommand,
      updateSettings,
      controlPower,
      controlColor,
      controlBrightness,
      controlScene,
      startMusicMode,
      stopMusicMode,
      executeCommand,
      matchAndExecute,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): Ctx {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}

function seedCommands(): VoiceCommand[] {
  return [
    {
      id: uid(),
      phrase: "turn lights on",
      action: "on",
      target: { kind: "all" },
      enabled: true,
    },
    {
      id: uid(),
      phrase: "turn lights off",
      action: "off",
      target: { kind: "all" },
      enabled: true,
    },
    {
      id: uid(),
      phrase: "party mode",
      action: "scene",
      target: { kind: "all" },
      scene: "party",
      enabled: true,
    },
    {
      id: uid(),
      phrase: "music vibe",
      action: "music",
      target: { kind: "all" },
      enabled: true,
    },
  ];
}

function scorePhrase(transcript: string, phrase: string): number {
  const t = transcript.toLowerCase().replace(/[^a-z0-9 ]/g, "").trim();
  const p = phrase.toLowerCase().replace(/[^a-z0-9 ]/g, "").trim();
  if (!t || !p) return 0;
  if (t === p) return 1;
  if (t.includes(p)) return 0.95;
  const tt = new Set(t.split(/\s+/).filter(Boolean));
  const pp = p.split(/\s+/).filter(Boolean);
  if (pp.length === 0) return 0;
  let hits = 0;
  for (const w of pp) if (tt.has(w)) hits++;
  return hits / pp.length;
}

function hsvToRgb(h: number, s: number, v: number): RGB {
  const c = v * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = v - c;
  let r = 0, g = 0, b = 0;
  if (h < 60) [r, g, b] = [c, x, 0];
  else if (h < 120) [r, g, b] = [x, c, 0];
  else if (h < 180) [r, g, b] = [0, c, x];
  else if (h < 240) [r, g, b] = [0, x, c];
  else if (h < 300) [r, g, b] = [x, 0, c];
  else [r, g, b] = [c, 0, x];
  return {
    r: Math.round((r + m) * 255),
    g: Math.round((g + m) * 255),
    b: Math.round((b + m) * 255),
  };
}
