import React, { useMemo, useState } from "react";
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useLocalSearchParams, useNavigation, useRouter } from "expo-router";
import ColorPicker from "react-native-wheel-color-picker";

import { useColors } from "@/hooks/useColors";
import { useApp } from "@/contexts/AppContext";
import { Slider } from "@/components/Slider";
import { PrimaryButton } from "@/components/PrimaryButton";
import type { RGB, Scene } from "@/lib/types";

const SCENES: { key: Scene; label: string; icon: keyof typeof Feather.glyphMap }[] = [
  { key: "rainbow", label: "Rainbow", icon: "sun" },
  { key: "warm", label: "Warm", icon: "coffee" },
  { key: "cool", label: "Cool", icon: "wind" },
  { key: "party", label: "Party", icon: "music" },
  { key: "calm", label: "Calm", icon: "feather" },
  { key: "fire", label: "Fire", icon: "thermometer" },
  { key: "ocean", label: "Ocean", icon: "droplet" },
];

export default function GroupScreen() {
  const colors = useColors();
  const router = useRouter();
  const navigation = useNavigation();
  const { id: rawId } = useLocalSearchParams<{ id: string }>();
  const id = decodeURIComponent(rawId ?? "");
  const {
    groups,
    devices,
    updateGroup,
    removeGroup,
    controlPower,
    controlColor,
    controlBrightness,
    controlScene,
    musicMode,
    startMusicMode,
    stopMusicMode,
  } = useApp();

  const group = groups.find((g) => g.id === id);
  const [editingName, setEditingName] = useState(false);
  const [name, setName] = useState(group?.name ?? "");
  const [tempColor, setTempColor] = useState<RGB>({ r: 255, g: 255, b: 255 });
  const [brightness, setBrightness] = useState(100);

  const target = useMemo(() => ({ kind: "group" as const, id }), [id]);
  const musicActive =
    musicMode.active && musicMode.target?.kind === "group" && musicMode.target.id === id;

  React.useEffect(() => {
    if (group) navigation.setOptions({ title: group.name });
  }, [navigation, group]);

  if (!group) {
    return (
      <View style={[styles.empty, { backgroundColor: colors.background }]}>
        <Feather name="alert-circle" size={36} color={colors.mutedForeground} />
        <Text style={{ color: colors.foreground, marginTop: 12, fontFamily: "Inter_600SemiBold" }}>
          Group not found
        </Text>
        <PrimaryButton style={{ marginTop: 16 }} label="Go back" icon="arrow-left" onPress={() => router.back()} />
      </View>
    );
  }

  const groupDevices = devices.filter((d) => group.deviceIds.includes(d.id));

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={styles.scroll}
      keyboardShouldPersistTaps="handled"
    >
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {editingName ? (
          <TextInput
            value={name}
            autoFocus
            onChangeText={setName}
            onBlur={() => {
              setEditingName(false);
              if (name.trim()) updateGroup({ ...group, name: name.trim() });
            }}
            style={[styles.nameInput, { color: colors.foreground, borderColor: colors.border }]}
          />
        ) : (
          <Pressable onPress={() => setEditingName(true)}>
            <Text style={[styles.name, { color: colors.foreground }]}>{group.name}</Text>
            <Text style={[styles.nameSub, { color: colors.mutedForeground }]}>
              {groupDevices.length} {groupDevices.length === 1 ? "light" : "lights"} • tap to rename
            </Text>
          </Pressable>
        )}

        <View style={{ flexDirection: "row", gap: 8, marginTop: 8 }}>
          <PrimaryButton fullWidth icon="sun" label="On" onPress={() => controlPower(target, true)} style={{ flex: 1 }} />
          <PrimaryButton fullWidth icon="moon" label="Off" variant="secondary" onPress={() => controlPower(target, false)} style={{ flex: 1 }} />
        </View>
      </View>

      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>Color</Text>
        <View style={styles.wheel}>
          <ColorPicker
            color={`rgb(${tempColor.r}, ${tempColor.g}, ${tempColor.b})`}
            onColorChange={(hex: string) => {
              const rgb = hexToRgb(hex);
              if (rgb) setTempColor(rgb);
            }}
            onColorChangeComplete={(hex: string) => {
              const rgb = hexToRgb(hex);
              if (rgb) {
                setTempColor(rgb);
                void controlColor(target, rgb);
              }
            }}
            thumbSize={28}
            sliderSize={28}
            noSnap
            row={false}
            swatches={false}
          />
        </View>
      </View>

      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Text style={[styles.cardTitle, { color: colors.foreground, flex: 1 }]}>Brightness</Text>
          <Text style={[styles.cardSub, { color: colors.mutedForeground }]}>{brightness}%</Text>
        </View>
        <Slider
          value={brightness}
          onChange={setBrightness}
          onCommit={(v) => controlBrightness(target, v)}
          fillColor={`rgb(${tempColor.r},${tempColor.g},${tempColor.b})`}
        />
      </View>

      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>Scenes</Text>
        <View style={styles.sceneGrid}>
          {SCENES.map((s) => (
            <Pressable
              key={s.key}
              onPress={() => controlScene(target, s.key)}
              style={[styles.sceneBtn, { backgroundColor: colors.secondary, borderColor: colors.border }]}
            >
              <Feather name={s.icon} size={20} color={colors.primary} />
              <Text style={[styles.sceneText, { color: colors.foreground }]}>{s.label}</Text>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>Music vibe</Text>
        <PrimaryButton
          fullWidth
          icon={musicActive ? "square" : "music"}
          label={musicActive ? "Stop music vibe" : "Start music vibe"}
          variant={musicActive ? "danger" : "primary"}
          onPress={() => (musicActive ? stopMusicMode() : startMusicMode(target))}
        />
      </View>

      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <PrimaryButton
          fullWidth
          variant="danger"
          icon="trash-2"
          label="Delete group"
          onPress={() =>
            Alert.alert("Delete this group?", group.name, [
              { text: "Cancel", style: "cancel" },
              {
                text: "Delete",
                style: "destructive",
                onPress: async () => {
                  await removeGroup(group.id);
                  router.back();
                },
              },
            ])
          }
        />
      </View>
    </ScrollView>
  );
}

function hexToRgb(hex: string): RGB | null {
  if (hex.startsWith("rgb")) {
    const m = hex.match(/(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
    if (!m) return null;
    return { r: +m[1]!, g: +m[2]!, b: +m[3]! };
  }
  const v = hex.replace("#", "");
  if (v.length !== 6) return null;
  return {
    r: parseInt(v.slice(0, 2), 16),
    g: parseInt(v.slice(2, 4), 16),
    b: parseInt(v.slice(4, 6), 16),
  };
}

const styles = StyleSheet.create({
  scroll: { padding: 16, paddingBottom: 60, gap: 14 },
  empty: { flex: 1, alignItems: "center", justifyContent: "center" },
  card: { padding: 16, borderRadius: 18, borderWidth: 1, gap: 12 },
  cardTitle: { fontFamily: "Inter_700Bold", fontSize: 16 },
  cardSub: { fontFamily: "Inter_400Regular", fontSize: 13 },
  name: { fontFamily: "Inter_700Bold", fontSize: 22 },
  nameSub: { fontFamily: "Inter_400Regular", fontSize: 13, marginTop: 4 },
  nameInput: {
    fontFamily: "Inter_700Bold",
    fontSize: 22,
    borderBottomWidth: 1,
    paddingVertical: 4,
  },
  wheel: { height: 260, alignItems: "center", justifyContent: "center" },
  sceneGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  sceneBtn: {
    minWidth: 96,
    flexBasis: "30%",
    flexGrow: 1,
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    gap: 6,
  },
  sceneText: { fontFamily: "Inter_500Medium", fontSize: 13 },
});
