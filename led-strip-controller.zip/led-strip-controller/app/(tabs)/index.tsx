import React from "react";
import {
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";

import { useColors } from "@/hooks/useColors";
import { useApp } from "@/contexts/AppContext";
import { DeviceCard } from "@/components/DeviceCard";
import { PrimaryButton } from "@/components/PrimaryButton";

export default function LightsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { devices, controlPower } = useApp();

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={devices}
        keyExtractor={(d) => d.id}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <View style={{ paddingBottom: 12, gap: 12 }}>
            <View style={[styles.heroRow, { borderColor: colors.border, backgroundColor: colors.card }]}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.heroTitle, { color: colors.foreground }]}>
                  Quick control
                </Text>
                <Text style={[styles.heroSub, { color: colors.mutedForeground }]}>
                  All paired lights
                </Text>
              </View>
              <View style={styles.heroBtns}>
                <Pressable
                  onPress={() => controlPower({ kind: "all" }, true)}
                  style={[styles.heroBtn, { backgroundColor: colors.primary }]}
                >
                  <Feather name="sun" size={18} color={colors.primaryForeground} />
                </Pressable>
                <Pressable
                  onPress={() => controlPower({ kind: "all" }, false)}
                  style={[
                    styles.heroBtn,
                    { backgroundColor: colors.secondary, borderColor: colors.border, borderWidth: 1 },
                  ]}
                >
                  <Feather name="moon" size={18} color={colors.foreground} />
                </Pressable>
              </View>
            </View>
            <PrimaryButton
              fullWidth
              icon="search"
              label="Find new lights"
              onPress={() => router.push("/scan")}
            />
          </View>
        }
        renderItem={({ item }) => (
          <View style={{ marginBottom: 10 }}>
            <DeviceCard device={item} />
          </View>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="bluetooth" size={36} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              No lights paired yet
            </Text>
            <Text style={[styles.emptySub, { color: colors.mutedForeground }]}>
              Tap "Find new lights" to scan and pair your LED strips.
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  listContent: { padding: 16, paddingBottom: 120 },
  heroRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderRadius: 18,
    borderWidth: 1,
    gap: 12,
  },
  heroTitle: { fontFamily: "Inter_700Bold", fontSize: 18 },
  heroSub: { fontFamily: "Inter_400Regular", fontSize: 13, marginTop: 2 },
  heroBtns: { flexDirection: "row", gap: 10 },
  heroBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  empty: {
    alignItems: "center",
    paddingVertical: 60,
    paddingHorizontal: 24,
    gap: 8,
  },
  emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 16, marginTop: 12 },
  emptySub: { fontFamily: "Inter_400Regular", fontSize: 13, textAlign: "center" },
});
