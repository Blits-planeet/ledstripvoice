import React, { useMemo, useState } from "react";
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";

import { useColors } from "@/hooks/useColors";
import { useApp } from "@/contexts/AppContext";
import { PrimaryButton } from "@/components/PrimaryButton";
import { Slider } from "@/components/Slider";
import type {
  CommandActionKind,
  CommandTarget,
  RGB,
  Scene,
  VoiceCommand,
} from "@/lib/types";

const ACTIONS: { key: CommandActionKind; label: string; icon: keyof typeof Feather.glyphMap }[] = [
  { key: "on", label: "Turn on", icon: "sun" },
  { key: "off", label: "Turn off", icon: "moon" },
  { key: "color", label: "Set color", icon: "droplet" },
  { key: "brightness", label: "Brightness", icon: "sliders" },
  { key: "scene", label: "Scene", icon: "image" },
  { key: "music", label: "Music vibe", icon: "music" },
];

const SCENES: Scene[] = ["rainbow", "warm", "cool", "party", "calm", "fire", "ocean"];

const COLOR_SWATCHES: RGB[] = [
  { r: 255, g: 255, b: 255 },
  { r: 255, g: 80, b: 80 },
  { r: 255, g: 170, b: 60 },
  { r: 255, g: 230, b: 80 },
  { r: 80, g: 220, b: 120 },
  { r: 60, g: 160, b: 255 },
  { r: 168, g: 85, b: 247 },
  { r: 255, g: 60, b: 200 },
];

function uid(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

export default function CommandEditScreen() {
  const colors = useColors();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const { commands, devices, groups, upsertCommand } = useApp();

  const existing = useMemo(
    () => (id ? commands.find((c) => c.id === id) : undefined),
    [id, commands],
  );

  const [phrase, setPhrase] = useState(existing?.phrase ?? "");
  const [action, setAction] = useState<CommandActionKind>(existing?.action ?? "on");
  const [target, setTarget] = useState<CommandTarget>(existing?.target ?? { kind: "all" });
  const [color, setColor] = useState<RGB>(existing?.color ?? { r: 255, g: 255, b: 255 });
  const [brightness, setBrightness] = useState<number>(existing?.brightness ?? 80);
  const [scene, setScene] = useState<Scene>(existing?.scene ?? "rainbow");

  function save() {
    if (!phrase.trim()) return;
    const cmd: VoiceCommand = {
      id: existing?.id ?? uid(),
      phrase: phrase.trim(),
      action,
      target,
      enabled: existing?.enabled ?? true,
      ...(action === "color" ? { color } : {}),
      ...(action === "brightness" ? { brightness } : {}),
      ...(action === "scene" ? { scene } : {}),
    };
    upsertCommand(cmd);
    router.back();
  }

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={styles.scroll}
      keyboardShouldPersistTaps="handled"
    >
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.label, { color: colors.mutedForeground }]}>Trigger phrase</Text>
        <TextInput
          value={phrase}
          onChangeText={setPhrase}
          placeholder='e.g. "turn lights off"'
          placeholderTextColor={colors.mutedForeground}
          autoFocus
          style={[
            styles.input,
            { backgroundColor: colors.input, color: colors.foreground, borderColor: colors.border },
          ]}
        />
      </View>

      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.label, { color: colors.mutedForeground }]}>Action</Text>
        <View style={styles.grid}>
          {ACTIONS.map((a) => (
            <Pressable
              key={a.key}
              onPress={() => setAction(a.key)}
              style={[
                styles.gridItem,
                {
                  backgroundColor: action === a.key ? colors.primary : colors.secondary,
                  borderColor: action === a.key ? colors.primary : colors.border,
                },
              ]}
            >
              <Feather
                name={a.icon}
                size={18}
                color={action === a.key ? colors.primaryForeground : colors.foreground}
              />
              <Text
                style={[
                  styles.gridText,
                  { color: action === a.key ? colors.primaryForeground : colors.foreground },
                ]}
              >
                {a.label}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {action === "color" ? (
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.label, { color: colors.mutedForeground }]}>Color</Text>
          <View style={styles.swatches}>
            {COLOR_SWATCHES.map((c, i) => {
              const selected = c.r === color.r && c.g === color.g && c.b === color.b;
              return (
                <Pressable
                  key={i}
                  onPress={() => setColor(c)}
                  style={[
                    styles.swatch,
                    {
                      backgroundColor: `rgb(${c.r},${c.g},${c.b})`,
                      borderColor: selected ? colors.primary : colors.border,
                      borderWidth: selected ? 3 : 1,
                    },
                  ]}
                />
              );
            })}
          </View>
        </View>
      ) : null}

      {action === "brightness" ? (
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={{ flexDirection: "row" }}>
            <Text style={[styles.label, { color: colors.mutedForeground, flex: 1 }]}>Brightness</Text>
            <Text style={[styles.label, { color: colors.foreground }]}>{brightness}%</Text>
          </View>
          <Slider value={brightness} onChange={setBrightness} />
        </View>
      ) : null}

      {action === "scene" ? (
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.label, { color: colors.mutedForeground }]}>Scene</Text>
          <View style={styles.grid}>
            {SCENES.map((s) => (
              <Pressable
                key={s}
                onPress={() => setScene(s)}
                style={[
                  styles.gridItem,
                  {
                    backgroundColor: scene === s ? colors.primary : colors.secondary,
                    borderColor: scene === s ? colors.primary : colors.border,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.gridText,
                    { color: scene === s ? colors.primaryForeground : colors.foreground },
                  ]}
                >
                  {s}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>
      ) : null}

      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.label, { color: colors.mutedForeground }]}>Apply to</Text>
        <Pressable
          onPress={() => setTarget({ kind: "all" })}
          style={[
            styles.targetRow,
            {
              borderColor: target.kind === "all" ? colors.primary : colors.border,
              backgroundColor: target.kind === "all" ? "rgba(168,85,247,0.12)" : "transparent",
            },
          ]}
        >
          <Feather name="globe" size={18} color={colors.foreground} />
          <Text style={[styles.targetText, { color: colors.foreground, flex: 1 }]}>All lights</Text>
          {target.kind === "all" ? <Feather name="check" size={18} color={colors.primary} /> : null}
        </Pressable>

        {groups.length > 0 ? (
          <Text style={[styles.subLabel, { color: colors.mutedForeground }]}>Groups</Text>
        ) : null}
        {groups.map((g) => {
          const sel = target.kind === "group" && target.id === g.id;
          return (
            <Pressable
              key={g.id}
              onPress={() => setTarget({ kind: "group", id: g.id })}
              style={[
                styles.targetRow,
                {
                  borderColor: sel ? colors.primary : colors.border,
                  backgroundColor: sel ? "rgba(168,85,247,0.12)" : "transparent",
                },
              ]}
            >
              <Feather name="layers" size={18} color={colors.foreground} />
              <Text style={[styles.targetText, { color: colors.foreground, flex: 1 }]}>{g.name}</Text>
              {sel ? <Feather name="check" size={18} color={colors.primary} /> : null}
            </Pressable>
          );
        })}

        {devices.length > 0 ? (
          <Text style={[styles.subLabel, { color: colors.mutedForeground }]}>Lights</Text>
        ) : null}
        {devices.map((d) => {
          const sel = target.kind === "device" && target.id === d.id;
          return (
            <Pressable
              key={d.id}
              onPress={() => setTarget({ kind: "device", id: d.id })}
              style={[
                styles.targetRow,
                {
                  borderColor: sel ? colors.primary : colors.border,
                  backgroundColor: sel ? "rgba(168,85,247,0.12)" : "transparent",
                },
              ]}
            >
              <Feather name="zap" size={18} color={colors.foreground} />
              <Text style={[styles.targetText, { color: colors.foreground, flex: 1 }]}>{d.name}</Text>
              {sel ? <Feather name="check" size={18} color={colors.primary} /> : null}
            </Pressable>
          );
        })}
      </View>

      <PrimaryButton
        fullWidth
        icon="check"
        label={existing ? "Save changes" : "Add command"}
        disabled={!phrase.trim()}
        onPress={save}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { padding: 16, paddingBottom: 60, gap: 14 },
  card: { padding: 16, borderRadius: 18, borderWidth: 1, gap: 10 },
  label: {
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    textTransform: "uppercase",
    letterSpacing: 1,
  },
  subLabel: {
    fontFamily: "Inter_500Medium",
    fontSize: 11,
    textTransform: "uppercase",
    letterSpacing: 1,
    marginTop: 8,
  },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontFamily: "Inter_500Medium",
    fontSize: 15,
  },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  gridItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 999,
    borderWidth: 1,
  },
  gridText: { fontFamily: "Inter_500Medium", fontSize: 13, textTransform: "capitalize" },
  swatches: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  swatch: { width: 38, height: 38, borderRadius: 19 },
  targetRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  targetText: { fontFamily: "Inter_500Medium", fontSize: 14 },
});
