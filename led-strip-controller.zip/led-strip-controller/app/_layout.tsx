import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect, useState } from "react";
import { StatusBar } from "expo-status-bar";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AppProvider } from "@/contexts/AppContext";
import { PermissionsBoot } from "@/components/PermissionsBoot";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

function RootLayoutNav() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: "#0a0a14" },
        headerTitleStyle: { color: "#f5f5f7", fontFamily: "Inter_600SemiBold" },
        headerTintColor: "#a855f7",
        headerBackTitle: "Back",
        contentStyle: { backgroundColor: "#0a0a14" },
      }}
    >
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen
        name="strip/[id]"
        options={{ title: "Light", presentation: "card" }}
      />
      <Stack.Screen
        name="group/[id]"
        options={{ title: "Group", presentation: "card" }}
      />
      <Stack.Screen
        name="scan"
        options={{ title: "Find lights", presentation: "modal" }}
      />
      <Stack.Screen
        name="command/edit"
        options={{ title: "Command", presentation: "modal" }}
      />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });
  const [permsDone, setPermsDone] = useState(false);

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1, backgroundColor: "#0a0a14" }}>
            <KeyboardProvider>
              <AppProvider>
                <StatusBar style="light" />
                {permsDone ? (
                  <RootLayoutNav />
                ) : (
                  <PermissionsBoot onReady={() => setPermsDone(true)} />
                )}
              </AppProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
