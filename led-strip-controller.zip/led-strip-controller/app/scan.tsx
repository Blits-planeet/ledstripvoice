import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";

import { useColors } from "@/hooks/useColors";
import { useApp } from "@/contexts/AppContext";
import {
  connect,
  disconnect,
  looksLikeLed,
  scanForDevices,
  ScanResult,
  stopScan,
} from "@/lib/ble";
import { PrimaryButton } from "@/components/PrimaryButton";

export default function ScanScreen() {
  const colors = useColors();
  const router = useRouter();
  const { devices, upsertDevice } = useApp();
  const [scanning, setScanning] = useState(false);
  const [results, setResults] = useState<ScanResult[]>([]);
  const [filterLed, setFilterLed] = useState(true);
  const [pairing, setPairing] = useState<string | null>(null);
  const cancelRef = useRef(false);

  useEffect(() => {
    void startScan();
    return () => {
      cancelRef.current = true;
      stopScan();
    };
  }, []);

  async function startScan() {
    setResults([]);
    setScanning(true);
    cancelRef.current = false;
    try {
      await scanForDevices((d) => {
        setResults((prev) => {
          if (prev.some((p) => p.id === d.id)) return prev;
          return [...prev, d].sort((a, b) => (b.rssi ?? -200) - (a.rssi ?? -200));
        });
      }, 8000);
    } catch (e: any) {
      Alert.alert("Scan failed", e?.message ?? String(e));
    } finally {
      if (!cancelRef.current) setScanning(false);
    }
  }

  async function pair(item: ScanResult) {
    setPairing(item.id);
    try {
      await connect(item.id);
      await upsertDevice({
        id: item.id,
        name: item.name,
        color: { r: 255, g: 255, b: 255 },
        brightness: 100,
        isOn: true,
        lastSeen: Date.now(),
      });
      router.back();
    } catch (e: any) {
      Alert.alert("Pairing failed", e?.message ?? String(e));
      try {
        await disconnect(item.id);
      } catch {
        /* ignore */
      }
    } finally {
      setPairing(null);
    }
  }

  const visible = filterLed ? results.filter((r) => looksLikeLed(r.name)) : results;
  const pairedIds = new Set(devices.map((d) => d.id));

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { borderColor: colors.border }]}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.title, { color: colors.foreground }]}>
            {scanning ? "Scanning…" : `${visible.length} device${visible.length === 1 ? "" : "s"} found`}
          </Text>
          <Text style={[styles.sub, { color: colors.mutedForeground }]}>
            Make sure your LED strip is powered on and not connected in another app.
          </Text>
        </View>
        {scanning ? <ActivityIndicator color={colors.primary} /> : null}
      </View>

      <View style={[styles.filterRow, { borderColor: colors.border, backgroundColor: colors.card }]}>
        <Feather name="filter" size={16} color={colors.foreground} />
        <Text style={[styles.filterLabel, { color: colors.foreground, flex: 1 }]}>
          Only show likely LED strips
        </Text>
        <Switch
          value={filterLed}
          onValueChange={setFilterLed}
          trackColor={{ false: colors.secondary, true: colors.primary }}
        />
      </View>

      <FlatList
        data={visible}
        keyExtractor={(d) => d.id}
        contentContainerStyle={{ padding: 16, paddingBottom: 120 }}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
        renderItem={({ item }) => {
          const paired = pairedIds.has(item.id);
          return (
            <View
              style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}
            >
              <View style={{ flex: 1 }}>
                <Text style={[styles.name, { color: colors.foreground }]} numberOfLines={1}>
                  {item.name}
                </Text>
                <Text style={[styles.id, { color: colors.mutedForeground }]} numberOfLines={1}>
                  {item.id} • RSSI {item.rssi ?? "?"}
                </Text>
              </View>
              {paired ? (
                <View style={styles.pairedTag}>
                  <Feather name="check" size={14} color={colors.accent} />
                  <Text style={[styles.pairedText, { color: colors.accent }]}>Paired</Text>
                </View>
              ) : (
                <Pressable
                  onPress={() => pair(item)}
                  disabled={!!pairing}
                  style={[
                    styles.pairBtn,
                    {
                      backgroundColor: pairing === item.id ? colors.secondary : colors.primary,
                      opacity: pairing && pairing !== item.id ? 0.5 : 1,
                    },
                  ]}
                >
                  {pairing === item.id ? (
                    <ActivityIndicator color={colors.foreground} size="small" />
                  ) : (
                    <Text style={[styles.pairText, { color: colors.primaryForeground }]}>
                      Pair
                    </Text>
                  )}
                </Pressable>
              )}
            </View>
          );
        }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Feather name="bluetooth" size={32} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              {scanning ? "Looking around…" : "Nothing found"}
            </Text>
            <Text style={[styles.emptySub, { color: colors.mutedForeground }]}>
              {scanning
                ? "BLE devices will appear here as they're discovered."
                : "Toggle the filter off if you don't see your strip, or tap rescan."}
            </Text>
          </View>
        }
      />

      <View style={{ padding: 16, paddingBottom: 28, gap: 8 }}>
        <PrimaryButton
          fullWidth
          icon={scanning ? "x" : "refresh-cw"}
          label={scanning ? "Stop scan" : "Rescan"}
          onPress={() => {
            if (scanning) {
              stopScan();
              setScanning(false);
            } else {
              void startScan();
            }
          }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  title: { fontFamily: "Inter_700Bold", fontSize: 18 },
  sub: { fontFamily: "Inter_400Regular", fontSize: 12, marginTop: 4 },
  filterRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    margin: 16,
    padding: 12,
    borderRadius: 14,
    borderWidth: 1,
  },
  filterLabel: { fontFamily: "Inter_500Medium", fontSize: 14 },
  card: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderRadius: 16,
    borderWidth: 1,
    gap: 12,
  },
  name: { fontFamily: "Inter_600SemiBold", fontSize: 15 },
  id: { fontFamily: "Inter_400Regular", fontSize: 11, marginTop: 2 },
  pairBtn: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 999,
    minWidth: 70,
    alignItems: "center",
  },
  pairText: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
  pairedTag: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8 },
  pairedText: { fontFamily: "Inter_600SemiBold", fontSize: 12 },
  empty: { alignItems: "center", paddingVertical: 48, paddingHorizontal: 24, gap: 8 },
  emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 16, marginTop: 12 },
  emptySub: { fontFamily: "Inter_400Regular", fontSize: 13, textAlign: "center" },
});
