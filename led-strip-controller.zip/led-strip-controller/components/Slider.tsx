import React, { useRef, useState } from "react";
import { PanResponder, StyleSheet, View } from "react-native";
import { useColors } from "@/hooks/useColors";

type Props = {
  value: number;
  min?: number;
  max?: number;
  onChange: (v: number) => void;
  onCommit?: (v: number) => void;
  trackColor?: string;
  fillColor?: string;
};

export function Slider({
  value,
  min = 0,
  max = 100,
  onChange,
  onCommit,
  trackColor,
  fillColor,
}: Props) {
  const colors = useColors();
  const [width, setWidth] = useState(0);
  const valueRef = useRef(value);
  valueRef.current = value;

  const responder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: (evt) => {
        if (!width) return;
        const x = evt.nativeEvent.locationX;
        const v = Math.round(min + (max - min) * Math.max(0, Math.min(1, x / width)));
        onChange(v);
      },
      onPanResponderMove: (evt) => {
        if (!width) return;
        const x = evt.nativeEvent.locationX;
        const v = Math.round(min + (max - min) * Math.max(0, Math.min(1, x / width)));
        onChange(v);
      },
      onPanResponderRelease: () => onCommit?.(valueRef.current),
      onPanResponderTerminate: () => onCommit?.(valueRef.current),
    }),
  ).current;

  const pct = Math.max(0, Math.min(1, (value - min) / (max - min)));

  return (
    <View
      style={[styles.track, { backgroundColor: trackColor ?? colors.secondary }]}
      onLayout={(e) => setWidth(e.nativeEvent.layout.width)}
      {...responder.panHandlers}
    >
      <View
        style={[
          styles.fill,
          {
            width: `${pct * 100}%`,
            backgroundColor: fillColor ?? colors.primary,
          },
        ]}
      />
      <View
        style={[
          styles.thumb,
          { left: `${pct * 100}%`, backgroundColor: colors.foreground },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  track: {
    height: 14,
    borderRadius: 999,
    justifyContent: "center",
    overflow: "visible",
  },
  fill: {
    position: "absolute",
    left: 0,
    top: 0,
    bottom: 0,
    borderRadius: 999,
  },
  thumb: {
    position: "absolute",
    width: 22,
    height: 22,
    borderRadius: 11,
    marginLeft: -11,
    elevation: 4,
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
  },
});
