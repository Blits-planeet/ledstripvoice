import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { useColors } from "@/hooks/useColors";
import type { Device } from "@/lib/types";
import { useApp } from "@/contexts/AppContext";

export function DeviceCard({ device }: { device: Device }) {
  const colors = useColors();
  const router = useRouter();
  const { controlPower, busy } = useApp();
  const isBusy = !!busy[device.id];
  const dotColor = `rgb(${device.color.r}, ${device.color.g}, ${device.color.b})`;

  return (
    <Pressable
      onPress={() => router.push(`/strip/${encodeURIComponent(device.id)}`)}
      style={({ pressed }) => [
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          opacity: pressed ? 0.85 : 1,
        },
      ]}
    >
      <View style={styles.row}>
        <View
          style={[
            styles.glow,
            {
              backgroundColor: device.isOn ? dotColor : colors.muted,
              shadowColor: device.isOn ? dotColor : "transparent",
            },
          ]}
        />
        <View style={{ flex: 1 }}>
          <Text style={[styles.name, { color: colors.foreground }]} numberOfLines={1}>
            {device.name}
          </Text>
          <Text style={[styles.sub, { color: colors.mutedForeground }]} numberOfLines={1}>
            {device.isOn ? `${device.brightness}% • on` : "off"}
          </Text>
        </View>
        <Pressable
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
            void controlPower({ kind: "device", id: device.id }, !device.isOn);
          }}
          disabled={isBusy}
          style={[
            styles.power,
            {
              backgroundColor: device.isOn ? colors.primary : colors.secondary,
              borderColor: colors.border,
              opacity: isBusy ? 0.5 : 1,
            },
          ]}
        >
          <Feather
            name="power"
            size={18}
            color={device.isOn ? colors.primaryForeground : colors.mutedForeground}
          />
        </Pressable>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1,
    borderRadius: 18,
    padding: 16,
  },
  row: { flexDirection: "row", alignItems: "center", gap: 14 },
  glow: {
    width: 20,
    height: 20,
    borderRadius: 10,
    shadowOpacity: 0.9,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 0 },
    elevation: 6,
  },
  name: { fontFamily: "Inter_600SemiBold", fontSize: 16 },
  sub: { fontFamily: "Inter_400Regular", fontSize: 13, marginTop: 2 },
  power: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 1,
  },
});
